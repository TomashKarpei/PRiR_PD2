package czasomierz;

public class Glowna {

	public static void main(String[] args) {
			new Czasomierz().start();
	}
}
