package czasomierz;

import java.util.Date;

public class Czasomierz extends Thread {
	int sek = 0;
	int min = 0;
	int godz = 0;

	public void run() {
		Date d=new Date();
		sek = d.getSeconds();
		min = d.getMinutes();
		godz = d.getHours();
		
		while(true)
		{
			try {
				Thread.sleep(1000);
				sek++;
				if (sek > 59)
				{
					min++;
					sek = 0;
					if (min > 59)
					{
						godz++;
						min = 0;
						if (godz > 23)
						{
							godz = 0;
						}
					}
				}
				if (godz < 10 && min < 10 && sek < 10) {
					System.out.println("0" + godz + " : 0" + min + " : 0" + sek);
				}
				else if (godz < 10  && sek < 10) {
					System.out.println("0" + godz + " : " + min + " : 0" + sek);
				}
				else if (godz < 10  && min < 10) {
					System.out.println("0" + godz + " : 0" + min + " : " + sek);
				}
				else if (min < 10  && sek < 10) {
					System.out.println(godz + " : 0" + min + " : 0" + sek);
				}
				else if (godz < 10) {
					System.out.println("0" + godz + " : " + min + " : " + sek);
				}
				else if (min < 10) {
					System.out.println(godz + " : 0" + min + " : " + sek);
				}
				else if (sek < 10) {
					System.out.println(godz + " : " + min + " : 0" + sek);
				}
				else {
					System.out.println(godz + " : " + min + " : " + sek);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
}
