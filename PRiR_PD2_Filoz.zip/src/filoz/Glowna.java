package filoz;

import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Glowna {
	static double MAX=100;
	static Semaphore [] widelec = new Semaphore [(int) MAX] ;
	public static void main ( String [] args ) {
		
		int m = 0;
		
		Scanner myObj = new Scanner(System.in); 
		
	    System.out.println("\nJak� metod� chcesz u�yc? (1, 2, lub 3) : ");
	    m = myObj.nextInt();
		if (m != 1 && m != 2 && m != 3)
			System.out.println("\nBrak metody " + m);
		else {
		    System.out.println("\nPodaj ilo�� filozof�w (od 2 do 100): ");
		    MAX = myObj.nextDouble();
		    if (MAX >=2 && MAX <= 100 ) {
		    	for ( int i =0; i<MAX; i++) {
					widelec [ i ]=new Semaphore ( 1 ) ;
				}
				for ( int i =0; i<MAX; i++) {
					if (m == 1) {
						new Filozof1(i, MAX, widelec).start();
					}
					else if (m == 2) {
						new Filozof2(i, MAX, widelec).start();
					}
					else if (m == 3) {
						new Filozof3(i, MAX, widelec).start();
					}
				}
		    }
		    else
		    	System.out.println("\nPodana nieprawid�owa ilo�� filozof�w. ");
		}
	}
}
