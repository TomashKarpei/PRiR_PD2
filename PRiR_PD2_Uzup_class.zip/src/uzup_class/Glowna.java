package uzup_class;


public class Glowna {

	public static void main(String[] args) { // symulacja dzia�ania klasy Samochod dla 1,2,3, � samochod�w
		new Samochod("1", 10).start();
	    new Samochod("2", 15).start();
	    new Samochod("3", 20).start();
	}
}
