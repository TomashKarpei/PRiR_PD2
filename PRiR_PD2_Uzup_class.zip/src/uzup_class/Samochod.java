package uzup_class;

import java.util.Random;

public class Samochod extends Thread {
	private volatile boolean exit;
	private Random random;
	private String nrRej;
	private int pojZbiornika;
	private int paliwo;
	
	
	public Samochod (String nrRej, int pojZbiornika) {
		this.nrRej = nrRej;
	    this.pojZbiornika = pojZbiornika;
	    random = new Random();
	}
	
	private void tankowanie (int paliwo) {
		if(paliwo > pojZbiornika + this.paliwo) {
            System.out.println("Do samochodu " + nrRej + " wlano za du�o paliwa");
            this.paliwo = pojZbiornika;
        }
        else {
            this.paliwo += paliwo;
        }
	}
	
	private void startSam() {	//start samochodu, uruchamiamy w�tek zu�ycia paliwa
		exit = false;
	}
	
	private void stopSam() {	//zatrzymanie samochodu, zatrzymujemy w�tek zu�ycia paliwa
		exit = true;
	}
	
	public void run() {		//kod, kt�ry wykonuje si� w odr�bnym w�tku, co 1 s programu zu�ywany jest 1 litr paliwa
		startSam();
        tankowanie(random.nextInt(100));

        while(!exit) {
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            paliwo--;
            if(paliwo <= 0) {
                System.out.println("Koniec paliwa w samochodzie " + nrRej + ". Koniec pojazdu");
                stopSam();
                break;
            }
            System.out.println("Pojazd " + nrRej + " posiada " + paliwo + "/" + pojZbiornika + " litr�w paliwa.");
        }
	}
}




 
 

