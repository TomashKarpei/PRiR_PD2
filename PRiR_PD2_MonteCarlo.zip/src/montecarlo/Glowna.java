package montecarlo;

public class Glowna {

	public static void main(String[] args) {
		new PolePow ().start();		
	}

}
