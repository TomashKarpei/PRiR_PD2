package montecarlo;

import java.util.Random;

public class PolePow extends Thread {
			private Random random;
		   	int i;                                                               
		   	int nThrows = 0;                                             
		   	int nSuccess = 0;
		   	double x = 0;
		   	double y = 0;
		   	double dx = 0;
		   	 
		   	public PolePow () {
			
			    this.random = new Random();
		   	}
		   	public void run() {
		   		while(true)
				{
					try {
						Thread.sleep(1000);
					   	 for (i = 0; i < 1000000 ; i++)                         
					   	 {                                                            
					   	    x = Math.random();    // losowanie x i y             
					   	    y = Math.random();
					   	   
					   									
					   	    nThrows++;                                                        
					   									
					   	    if ( x*x + y*y <= 1 )             
					   	       nSuccess++;                                               
					   	 }
					   	 double pi = 4*(double)nSuccess/(double)nThrows;
					   	System.out.println("Pole = " + pi);
					   	 
					   	}
					
					 catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
		   	}
}
